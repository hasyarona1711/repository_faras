<?php echo $this->extend('templateadmin');
echo $this->section('content'); ?>

<div class="container" style="min-height: 680px;">
    <div class="row align-items-center">
        <div class="col">
            <h1 class="display-4">Selamat Datang Admin</h1>
        </div>
    </div>
</div>


<?php echo $this->endSection(); ?>