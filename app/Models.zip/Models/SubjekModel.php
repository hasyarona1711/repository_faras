<?php

namespace App\Models;

use CodeIgniter\Model;

class SubjekModel extends Model
{
    protected $table = 'subjek';
}
