<?php

namespace App\Models;

use CodeIgniter\Model;

class JendokModel extends Model
{
    protected $table = 'jenis_dokumen';
}
