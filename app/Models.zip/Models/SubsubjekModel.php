<?php

namespace App\Models;

use CodeIgniter\Model;

class SubsubjekModel extends Model
{
    protected $table = 'sub_subjek';
}
